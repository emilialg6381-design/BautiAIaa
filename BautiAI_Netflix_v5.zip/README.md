# BautiAI – Login + PayPal (main + movies)

## Estructura
```
BautiAIaa-main/
├── users.json          ← BD de usuarios COMPARTIDA entre ambas apps
├── start_all.sh        ← Arranca main y movies juntos
├── main/
│   ├── server.py       ← App principal (puerto 5000) — ya integrada con auth
│   └── auth_middleware.py
└── movies/
    ├── server.py       ← App de películas (puerto 5001) — ya integrada con auth
    └── auth_middleware.py
```

## Cuenta preconfigurada
| Usuario | Contraseña |
|---------|-----------|
| BAUTIXD | Bauti12m  |

Una sola cuenta sirve para **ambos sitios** (comparten users.json).

## Variables de entorno
```bash
PAYPAL_SECRET=tu_client_secret_de_paypal   # para verificar suscripciones reales
FLASK_SECRET=clave_larga_aleatoria          # opcional, se genera automáticamente
```

## Cómo correr
```bash
chmod +x start_all.sh
./start_all.sh
```

## Cómo funciona
- Cualquier ruta (main o movies) sin sesión → redirige a `/login`
- El usuario se registra con usuario+contraseña+suscripción PayPal → cuenta guardada en `users.json`
- Cada login verifica en tiempo real si la suscripción PayPal sigue activa
- Si cancela la suscripción → no puede volver a entrar
