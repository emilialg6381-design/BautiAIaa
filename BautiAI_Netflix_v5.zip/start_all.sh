#!/bin/bash

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RED='\033[0;31m'
NC='\033[0m'

# ─── Auto-detect base dir ───────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$SCRIPT_DIR"
MAIN_DIR="$BASE_DIR/main"
MOVIES_DIR="$BASE_DIR/movies"

echo -e "${CYAN}╔══════════════════════════════════════╗${NC}"
echo -e "${CYAN}║      BAUTIAI NEXUS — FULL STACK     ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════╝${NC}"
echo ""
echo -e "Base:   ${GREEN}$BASE_DIR${NC}"
echo -e "Main:   ${GREEN}$MAIN_DIR${NC}"
echo -e "Movies: ${GREEN}$MOVIES_DIR${NC}"
echo ""

# ─── Kill old processes ─────────────────────────────────────────────────────
echo -e "${YELLOW}Limpiando procesos anteriores...${NC}"
pkill -f gunicorn 2>/dev/null
kill -9 $(lsof -t -i:5000) 2>/dev/null
kill -9 $(lsof -t -i:5001) 2>/dev/null
sleep 1

# ─── Activate venv if present ───────────────────────────────────────────────
if [ -f "$BASE_DIR/venv/bin/activate" ]; then
    source "$BASE_DIR/venv/bin/activate"
    echo -e "${GREEN}✓ Virtualenv activado${NC}"
fi

# ─── Start MAIN app (port 5000) ─────────────────────────────────────────────
echo -e "${GREEN}Iniciando MAIN (puerto 5000)...${NC}"
cd "$MAIN_DIR"
nohup gunicorn wsgi:app -c gunicorn.conf.py > "$MAIN_DIR/main.log" 2>&1 &
sleep 2

# ─── Start MOVIES app (port 5001) ───────────────────────────────────────────
echo -e "${GREEN}Iniciando MOVIES (puerto 5001)...${NC}"
cd "$MOVIES_DIR"
nohup gunicorn -w 2 -b 127.0.0.1:5001 server:app > "$MOVIES_DIR/movies.log" 2>&1 &
sleep 2

# ─── Restart Nginx ──────────────────────────────────────────────────────────
echo -e "${YELLOW}Reiniciando Nginx...${NC}"
sudo systemctl restart nginx 2>/dev/null || echo -e "${YELLOW}(Nginx no disponible, saltando)${NC}"

echo ""
echo -e "${GREEN}✅ Todo corriendo${NC}"
echo ""
echo -e "🌐 MAIN:   http://127.0.0.1:5000"
echo -e "🎬 MOVIES: http://127.0.0.1:5001"
echo ""
echo -e "${CYAN}Nota: ambos sitios comparten users.json — una cuenta sirve para los dos${NC}"
