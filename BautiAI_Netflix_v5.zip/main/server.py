import os
import time
import json
import uuid
import base64
import requests
import threading
from urllib.parse import urljoin, parse_qs, unquote
from flask import Flask, request, jsonify, render_template, Response, session, redirect
from auth_middleware import register_auth_routes, require_login
import google.generativeai as genai

# ─── CONFIG ────────────────────────────────────────────────────────────────────
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyDQwaWLyii0fkvMXfKpU7OkQBKHd03c86Q")
genai.configure(api_key=GEMINI_API_KEY)

app = Flask(__name__, static_folder='static', static_url_path='/static')
register_auth_routes(app)

BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
IMAGE_DIR  = os.path.join(BASE_DIR, 'static', 'images')
VIDEO_DIR  = os.path.join(BASE_DIR, 'static', 'videos')
TEMP_DIR   = os.path.join(BASE_DIR, 'temp')
ZAI_STORAGE = os.path.join(BASE_DIR, "zai_auth.json")

for d in [IMAGE_DIR, VIDEO_DIR, TEMP_DIR]:
    os.makedirs(d, exist_ok=True)

jobs: dict      = {}
jobs_lock       = threading.Lock()
chat_history    = []
chat_lock       = threading.Lock()

AD_DOMAINS = [
    "google-analytics", "doubleclick", "popads",
    "adskeeper", "googlesyndication", "adsense",
]

VIDEO_MODELS = {
    "grok": {"url": "https://veoaifree.com/grok-ai-video-generator/", "name": "Grok Video"},
    "veo":  {"url": "https://veoaifree.com/veo-video-generator/",      "name": "Veo Video"},
}


# ─── PLAYWRIGHT HELPERS ────────────────────────────────────────────────────────

def _adblock(route):
    if any(ad in route.request.url for ad in AD_DOMAINS):
        return route.abort()
    return route.continue_()


def _dismiss_popups(page, timeout=5000):
    """Try to dismiss cookie banners, modals, and overlays."""
    selectors = [
        'button:has-text("Accept")', 'button:has-text("Allow")',
        'button:has-text("Consent")', 'button:has-text("Got it")',
        'button:has-text("OK")', 'button:has-text("Close")',
        'button:has-text("Dismiss")', 'button:has-text("I agree")',
        '[class*="cookie"] button', '[class*="consent"] button',
        '[class*="popup"] button', '[class*="modal"] [class*="close"]',
        '[aria-label="Close"]', '[aria-label="Dismiss"]',
        '.fc-cta-consent', '#onetrust-accept-btn-handler',
    ]
    for sel in selectors:
        try:
            loc = page.locator(sel).first
            if loc.count() > 0 and loc.is_visible(timeout=800):
                loc.click(timeout=1000)
                page.wait_for_timeout(400)
        except Exception:
            pass

    try:
        page.keyboard.press("Escape")
        page.wait_for_timeout(300)
    except Exception:
        pass


def _click_by_text(page, text, exact=False, timeout=10_000):
    deadline = time.time() + timeout / 1000
    while time.time() < deadline:
        try:
            loc = page.get_by_text(text, exact=exact).first
            if loc.count() > 0 and loc.is_visible(timeout=1000):
                loc.scroll_into_view_if_needed(timeout=2000)
                page.wait_for_timeout(200)
                loc.click(timeout=3000)
                page.wait_for_timeout(500)
                return True
        except Exception:
            pass
        clicked = page.evaluate("""(args) => {
            const [text, exact] = args;
            const candidates = [];
            const all = document.querySelectorAll(
                'button,[role="button"],input[type="submit"],a,div,span,p,li,[class*="btn"],[class*="Btn"]'
            );
            for (const el of all) {
                if (el.offsetParent === null) continue;
                const style = window.getComputedStyle(el);
                if (style.display === 'none' || style.visibility === 'hidden') continue;
                const t = (el.innerText || '').trim();
                if (!t) continue;
                if (exact ? t === text : t.includes(text)) candidates.push({ el, len: t.length });
            }
            candidates.sort((a, b) => a.len - b.len);
            for (const { el } of candidates) {
                try { el.scrollIntoView({ block: 'center' }); el.click(); return true; } catch {}
            }
            return false;
        }""", [text, exact])
        if clicked:
            page.wait_for_timeout(500)
            return True
        page.wait_for_timeout(1000)
    raise Exception(f"Could not find clickable element: '{text}'")


def _fill_textarea(page, text, job_id=None):
    def progress(msg):
        if job_id:
            with jobs_lock:
                jobs[job_id].update({"progress": msg})

    progress("Waiting for text input\u2026")
    for get_loc in [
        lambda: page.locator("textarea:visible").last,
        lambda: page.locator("textarea:visible").first,
        lambda: page.locator("[contenteditable='true']:visible").last,
        lambda: page.locator("input[type='text']:visible").last,
    ]:
        try:
            loc = get_loc()
            if loc.count() > 0:
                loc.click(timeout=5000)
                page.wait_for_timeout(300)
                loc.fill(text, timeout=10_000)
                progress("Text entered")
                return
        except Exception:
            continue

    progress("Standard fill failed, trying keyboard\u2026")
    page.wait_for_timeout(500)
    page.keyboard.type(text, delay=20)
    progress("Text entered via keyboard")


def _find_generate_button(page, job_id=None):
    """Robustly find and click the Generate button. Returns True on success."""
    def progress(msg):
        if job_id:
            with jobs_lock:
                jobs[job_id].update({"progress": msg})

    selectors = [
        "#generate_it",
        "#generate_it_img_video",
        ".techwave_fn_button:has-text('Generate')",
        "button:has-text('Generate')",
        "button[type='submit']",
        "input[type='submit']",
        "[role='button']:has-text('Generate')",
        "button:has-text('generate')",
        "button:has-text('CREATE')",
        "button:has-text('Create')",
    ]
    for sel in selectors:
        try:
            btn = page.locator(sel).first
            if btn.count() > 0 and btn.is_visible(timeout=2000):
                btn.scroll_into_view_if_needed(timeout=2000)
                page.wait_for_timeout(200)
                btn.click(timeout=3000)
                progress(f"Clicked Generate via selector: {sel}")
                return True
        except Exception:
            continue

    for text in ["Generate", "generate", "Create Video", "Start", "Go"]:
        try:
            if _click_by_text(page, text, exact=False, timeout=5000):
                progress(f"Clicked Generate via text: '{text}'")
                return True
        except Exception:
            continue

    try:
        clicked = page.evaluate("""() => {
            const btns = document.querySelectorAll('button, [role="button"], input[type="submit"]');
            let best = null, bestScore = -1;
            for (const btn of btns) {
                if (btn.offsetParent === null) continue;
                const t = (btn.innerText || btn.value || '').toLowerCase();
                if (!t) continue;
                let score = 0;
                if (t.includes('generate')) score += 10;
                if (t.includes('create')) score += 5;
                if (t.includes('start')) score += 3;
                if (t.includes('go') && t.length < 10) score += 2;
                const style = window.getComputedStyle(btn);
                if (style.backgroundColor !== 'rgba(0, 0, 0, 0)' && style.backgroundColor !== 'transparent') score += 2;
                const rect = btn.getBoundingClientRect();
                if (rect.width > 80 && rect.height > 30) score += 1;
                if (score > bestScore) { bestScore = score; best = btn; }
            }
            if (best && bestScore >= 3) {
                best.scrollIntoView({ block: 'center' });
                best.click();
                return true;
            }
            return false;
        }""")
        if clicked:
            progress("Clicked Generate via JS heuristic")
            return True
    except Exception:
        pass

    return False


def _download_video_from_page(page, job_id=None, timeout=300_000):
    def progress(msg):
        if job_id:
            with jobs_lock:
                jobs[job_id].update({"progress": msg})

    progress("Waiting for video to be ready (this may take several minutes)\u2026")

    new_page = None
    try:
        with page.context.expect_page(timeout=8000) as new_page_info:
            pass
    except Exception:
        pass

    active_page = page
    if new_page:
        try:
            new_page.wait_for_load_state("domcontentloaded", timeout=10000)
            active_page = new_page
            progress("Video opened in new tab, following it\u2026")
        except Exception:
            pass

    try:
        active_page.wait_for_function("""() => {
            const videos = document.querySelectorAll('video');
            for (const v of videos) {
                const src = v.currentSrc || v.src || '';
                if (src.length > 5 && !src.startsWith('about:')) return true;
                if (v.srcObject) return true;
                if (v.videoWidth > 0 && v.videoHeight > 0) return true;
                if (v.readyState >= 2) return true;
                for (const s of v.querySelectorAll('source'))
                    if (s.src && s.src.length > 5 && !s.src.startsWith('about:')) return true;
            }
            const links = document.querySelectorAll('a');
            for (const a of links) {
                const href = a.href || '';
                if (href.endsWith('.mp4') || href.endsWith('.webm') || href.includes('/video/')) return true;
            }
            return false;
        }""", timeout=timeout)
    except Exception:
        page_text = ""
        try:
            page_text = active_page.evaluate("() => document.body.innerText.substring(0, 500)")
        except Exception:
            pass
        screenshot_path = None
        if job_id:
            screenshot_path = os.path.join(TEMP_DIR, f"debug_{job_id}.png")
            try:
                active_page.screenshot(path=screenshot_path)
            except Exception:
                pass
        msg = f"Video generation timed out after {timeout/1000:.0f}s."
        if page_text:
            msg += f" Page text: {page_text[:200]}"
        if screenshot_path:
            msg += f" Screenshot saved: /debug-screenshot/{job_id}"
        raise Exception(msg)

    progress("Video detected, waiting for data\u2026")
    page.wait_for_timeout(5000)

    video_src = None
    for attempt in range(10):
        info = active_page.evaluate("""() => {
            const videos = document.querySelectorAll('video');
            for (const v of videos) {
                const src = v.currentSrc || v.src || '';
                if (src.length > 10 && !src.startsWith('about:') && !src.startsWith('data:')) return { src, method: 'direct' };
            }
            for (const v of videos)
                for (const s of v.querySelectorAll('source'))
                    if (s.src && s.src.length > 10 && !s.src.startsWith('about:')) return { src: s.src, method: 'source-tag' };
            for (const a of document.querySelectorAll('a')) {
                const href = a.href || '';
                if ((href.endsWith('.mp4') || href.endsWith('.webm')) && href.startsWith('http')) return { src: href, method: 'link' };
            }
            for (const v of videos)
                if (v.srcObject || (v.videoWidth > 0 && v.readyState >= 2)) return { src: 'blob:srcObject', method: 'blob' };
            return null;
        }""")
        if info and info.get("src"):
            video_src = info["src"]
            progress(f"Found video source via {info.get('method', 'unknown')}: {video_src[:80]}\u2026")
            break
        progress(f"No URL yet, waiting\u2026 ({attempt+1}/10)")
        page.wait_for_timeout(8000)

    if not video_src:
        raise Exception("Video element appeared but no downloadable URL was found")

    content = b""
    for attempt in range(5):
        progress(f"Downloading video\u2026 (attempt {attempt+1}/5)")
        if video_src.startswith("blob:") or video_src == "blob:srcObject":
            fetch_url = video_src if video_src != "blob:srcObject" else None
            b64 = active_page.evaluate("""async (url) => {
                if (!url) return null;
                try {
                    const resp = await fetch(url);
                    if (!resp.ok) return null;
                    const blob = await resp.blob();
                    if (blob.size < 100) return null;
                    return new Promise(resolve => {
                        const reader = new FileReader();
                        reader.onloadend = () => resolve(reader.result);
                        reader.readAsDataURL(blob);
                    });
                } catch { return null; }
            }""", fetch_url)
            content = base64.b64decode(b64.split(",", 1)[1]) if b64 and "," in b64 else b""
        else:
            full_url = urljoin(active_page.url, video_src)
            try:
                headers = {}
                try:
                    cookies = active_page.context.cookies()
                    headers["Cookie"] = "; ".join(f"{c['name']}={c['value']}" for c in cookies)
                except Exception:
                    pass
                try:
                    ua = active_page.evaluate("() => navigator.userAgent")
                    headers["User-Agent"] = ua
                except Exception:
                    pass

                resp = requests.get(full_url, timeout=120, stream=True, headers=headers)
                resp.raise_for_status()
                content = resp.content
            except Exception as e:
                progress(f"Direct download failed: {e}, trying browser fetch\u2026")
                try:
                    b64 = active_page.evaluate("""async (url) => {
                        try {
                            const resp = await fetch(url, { credentials: 'include' });
                            if (!resp.ok) return null;
                            const blob = await resp.blob();
                            if (blob.size < 100) return null;
                            return new Promise(resolve => {
                                const reader = new FileReader();
                                reader.onloadend = () => resolve(reader.result);
                                reader.readAsDataURL(blob);
                            });
                        } catch { return null; }
                    }""", full_url)
                    if b64 and "," in b64:
                        content = base64.b64decode(b64.split(",", 1)[1])
                except Exception:
                    content = b""

        if len(content) >= 1000:
            progress(f"Video downloaded ({len(content) / 1024:.0f} KB)")
            return content

        progress(f"Only {len(content)} bytes, retrying\u2026")
        page.wait_for_timeout(8000)
        info = active_page.evaluate("""() => {
            const videos = document.querySelectorAll('video');
            for (const v of videos) { const s = v.currentSrc || v.src || ''; if (s.length > 10) return { src: s }; }
            for (const v of videos)
                for (const s of v.querySelectorAll('source'))
                    if (s.src && s.src.length > 10) return { src: s.src };
            return null;
        }""")
        if info and info.get("src"):
            video_src = info["src"]

    raise Exception(f"Video download failed \u2014 final size: {len(content)} bytes")


def _verify_image_uploaded(page):
    return page.evaluate("""() => {
        const imgs = document.querySelectorAll('img');
        for (const img of imgs) {
            const src = img.src || '';
            const w = img.naturalWidth || 0;
            if (w > 50 && !src.includes('logo') && !src.includes('icon')
                && !src.includes('.svg') && !src.includes('data:image/svg') && src.length > 20) return true;
        }
        const previews = document.querySelectorAll('[class*="preview"],[class*="thumbnail"],[class*="uploaded-image"]');
        for (const p of previews) if (p.offsetHeight > 20 && p.offsetWidth > 20) return true;
        return false;
    }""")


def _upload_image_to_page(page, image_path, job_id):
    def progress(msg):
        with jobs_lock:
            jobs[job_id].update({"progress": msg})

    progress("Looking for file inputs\u2026")
    file_inputs = page.locator("input[type='file']")
    for i in range(file_inputs.count()):
        try:
            progress(f"Trying file input {i+1}/{file_inputs.count()}\u2026")
            file_inputs.nth(i).set_files(image_path)
            page.wait_for_timeout(2500)
            if _verify_image_uploaded(page):
                progress("Image uploaded via file input!")
                return True
            try:
                file_inputs.nth(i).evaluate("el => el.value = ''")
            except Exception:
                pass
        except Exception:
            continue

    for selector in [".lucide-image-up-icon","[class*='upload-icon']","[class*='image-upload']","label[for*='upload']"]:
        try:
            progress(f"Trying selector: {selector}")
            with page.expect_file_chooser(timeout=4000) as fc:
                page.locator(selector).first.click(timeout=3000)
            fc.value.set_files(image_path)
            page.wait_for_timeout(2500)
            if _verify_image_uploaded(page):
                progress("Image uploaded via click!")
                return True
        except Exception:
            continue

    revealed = page.evaluate("""() => {
        const inputs = document.querySelectorAll('input[type="file"]');
        for (const inp of inputs) {
            inp.style.cssText = 'display:block!important;opacity:1;position:fixed;top:0;left:0;z-index:999999';
            inp.removeAttribute('hidden');
        }
        return inputs.length;
    }""")
    if revealed > 0:
        for i in range(page.locator("input[type='file']:visible").count()):
            try:
                page.locator("input[type='file']:visible").nth(i).set_files(image_path)
                page.wait_for_timeout(2500)
                if _verify_image_uploaded(page):
                    progress("Image uploaded via revealed input!")
                    return True
            except Exception:
                continue

    return False


# ─── TASK CLASSES ──────────────────────────────────────────────────────────────

class AutomationTask:
    def __init__(self, job_id, prompt, mode, aspect_val,
                 video_model="grok", image_path=None):
        self.job_id      = job_id
        self.prompt      = prompt
        self.mode        = mode
        self.aspect_val  = aspect_val
        self.video_model = video_model
        self.image_path  = image_path

    def _progress(self, msg):
        with jobs_lock:
            jobs[self.job_id].update({"progress": msg})

    def run(self):
        from playwright.sync_api import sync_playwright
        pw = sync_playwright().start()
        browser = None
        try:
            browser = pw.chromium.launch(
                headless=True,
                args=["--disable-gpu", "--no-sandbox", "--disable-dev-shm-usage"]
            )
            ctx  = browser.new_context(
                viewport={"width": 1280, "height": 800},
                user_agent=(
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
                ),
            )
            ctx.add_init_script(
                "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
            )
            page = ctx.new_page()
            page.route("**/*", _adblock)

            if self.mode == "image":
                self._gen_image(page)
            elif self.mode == "video":
                self._gen_video(page)
            elif self.mode == "image_to_video":
                self._gen_i2v(page)

            try:
                page.close()
                ctx.close()
                browser.close()
            except Exception:
                pass

        except Exception as e:
            with jobs_lock:
                current = jobs.get(self.job_id, {})
                if current.get("state") != "done":
                    jobs[self.job_id].update({"state": "error", "error": str(e)})
        finally:
            if browser:
                try:
                    browser.close()
                except Exception:
                    pass
            pw.stop()

    # ── IMAGE ──
    def _gen_image(self, page):
        self._progress("Opening image generator\u2026")
        for attempt in range(3):
            try:
                page.goto("https://freegen.app/", wait_until="domcontentloaded", timeout=45_000)
                page.wait_for_selector("textarea:visible", timeout=30_000)
                break
            except Exception:
                self._progress(f"Retry\u2026 ({attempt+1}/3)")
                page.wait_for_timeout(3000)
        else:
            raise Exception("Failed to load image generator")

        _dismiss_popups(page)
        page.wait_for_timeout(1000)
        _fill_textarea(page, self.prompt, job_id=self.job_id)
        page.wait_for_timeout(500)
        _click_by_text(page, "Generate")

        self._progress("Waiting for image\u2026")
        page.wait_for_selector("img[src*='data:image'], img[src*='http']", timeout=60_000)

        img_data = page.evaluate("""() => {
            const t = Array.from(document.querySelectorAll('img')).find(
                i => i.naturalWidth > 300 && !i.src.includes('logo')
            );
            return t ? t.src : null;
        }""")
        if not img_data:
            raise Exception("Could not extract image")

        filename = f"img_{self.job_id}.png"
        if "data:" in img_data:
            content = base64.b64decode(img_data.split(",")[1])
        else:
            content = requests.get(img_data, timeout=30).content

        with open(os.path.join(IMAGE_DIR, filename), "wb") as f:
            f.write(content)

        with jobs_lock:
            jobs[self.job_id].update({
                "state": "done",
                "url": f"/static/images/{filename}",
                "type": "image",
            })

    # ── VIDEO ──
    def _gen_video(self, page):
        model_info = VIDEO_MODELS.get(self.video_model, VIDEO_MODELS["grok"])
        self._progress(f"Opening {model_info['name']}\u2026")

        for attempt in range(3):
            try:
                page.goto(model_info["url"], wait_until="domcontentloaded", timeout=45_000)
                page.wait_for_load_state("networkidle", timeout=30_000)
                break
            except Exception:
                self._progress(f"Retry\u2026 ({attempt+1}/3)")
                page.wait_for_timeout(3000)
        else:
            raise Exception(f"Failed to load {model_info['name']}")

        _dismiss_popups(page)
        page.wait_for_timeout(1500)

        self._progress("Setting aspect ratio\u2026")
        try:
            gear = page.locator(".fn__svg.replaced-svg.svg-setting")
            if gear.count() > 0 and gear.first.is_visible(timeout=3000):
                gear.first.click()
                page.wait_for_timeout(500)
                ar_label = page.locator("label:has-text('Aspect Ratio'), :text('Aspect Ratio')")
                if ar_label.count() > 0:
                    ar_label.first.click()
                    page.wait_for_timeout(300)
                dropdown = page.locator("select:has(option[value='VIDEO_ASPECT_RATIO_LANDSCAPE'])")
                if dropdown.count() > 0:
                    dropdown.first.select_option(self.aspect_val)
                    page.wait_for_timeout(300)
                    try:
                        page.keyboard.press("Escape")
                    except Exception:
                        pass
        except Exception:
            self._progress("Could not set aspect ratio, using default")

        _dismiss_popups(page)
        page.wait_for_timeout(500)

        _fill_textarea(page, self.prompt, job_id=self.job_id)
        page.wait_for_timeout(500)

        self._progress("Clicking Generate\u2026")
        if not _find_generate_button(page, job_id=self.job_id):
            raise Exception(
                "Could not find the Generate button. "
                "The site layout may have changed."
            )

        try:
            page.wait_for_load_state("domcontentloaded", timeout=5000)
        except Exception:
            pass

        content = _download_video_from_page(page, job_id=self.job_id, timeout=300_000)

        filename = f"vid_{self.job_id}.mp4"
        with open(os.path.join(VIDEO_DIR, filename), "wb") as f:
            f.write(content)

        with jobs_lock:
            jobs[self.job_id].update({
                "state": "done",
                "url": f"/static/videos/{filename}",
                "type": "video",
                "size": len(content),
            })

    # ── IMAGE-TO-VIDEO ──
    def _gen_i2v(self, page):
        self._progress("Opening Image-to-Video generator\u2026")

        for attempt in range(3):
            try:
                page.goto(
                    "https://veoaifree.com/photo-and-image-to-video-generator/",
                    wait_until="domcontentloaded", timeout=45_000
                )
                page.wait_for_load_state("networkidle", timeout=30_000)
                break
            except Exception:
                self._progress(f"Retry\u2026 ({attempt+1}/3)")
                page.wait_for_timeout(3000)
        else:
            raise Exception("Failed to load Image-to-Video page")

        _dismiss_popups(page)
        page.wait_for_timeout(2000)

        if not self.image_path or not os.path.exists(self.image_path):
            raise Exception(f"Image file not found: {self.image_path}")

        if not _upload_image_to_page(page, self.image_path, self.job_id):
            raise Exception("Failed to upload image \u2014 the site may require a different upload method.")

        try:
            page.locator("#uploadBtn").click(timeout=3000)
            page.wait_for_timeout(1000)
        except Exception:
            pass

        if self.prompt:
            try:
                _fill_textarea(page, self.prompt, job_id=self.job_id)
            except Exception:
                pass

        page.wait_for_timeout(500)
        self._progress("Setting aspect ratio\u2026")
        try:
            gear = page.locator(".fn__svg.replaced-svg.svg-setting")
            if gear.count() > 0 and gear.first.is_visible():
                gear.first.click()
                page.wait_for_timeout(500)
            dropdown = page.locator("select:has(option[value='VIDEO_ASPECT_RATIO_LANDSCAPE'])")
            if dropdown.count() > 0:
                dropdown.first.select_option(self.aspect_val)
                page.wait_for_timeout(500)
                try:
                    page.keyboard.press("Escape")
                except Exception:
                    pass
        except Exception:
            pass

        _dismiss_popups(page)

        self._progress("Clicking Generate\u2026")
        generated = False
        try:
            btn = page.locator("#generate_it_img_video").first
            if btn.count() > 0 and btn.is_visible(timeout=3000):
                btn.click()
                generated = True
        except Exception:
            pass
        if not generated:
            generated = _find_generate_button(page, job_id=self.job_id)
        if not generated:
            raise Exception("Could not find the Generate button")

        try:
            page.wait_for_load_state("domcontentloaded", timeout=5000)
        except Exception:
            pass

        content = _download_video_from_page(page, job_id=self.job_id, timeout=300_000)

        filename = f"vid_{self.job_id}.mp4"
        with open(os.path.join(VIDEO_DIR, filename), "wb") as f:
            f.write(content)

        with jobs_lock:
            jobs[self.job_id].update({
                "state": "done",
                "url": f"/static/videos/{filename}",
                "type": "video",
                "size": len(content),
            })


class PromptGeneratorTask:
    """Uses Gemini via the chat-stream endpoint logic instead of browser scraping."""

    def __init__(self, job_id, idea):
        self.job_id = job_id
        self.idea   = idea

    def _progress(self, msg):
        with jobs_lock:
            jobs[self.job_id].update({"progress": msg})

    def run(self):
        self._progress("Generating prompt with Gemini\u2026")
        try:
            model = genai.GenerativeModel("gemini-2.0-flash")
            system = (
                "You are an expert AI image/video prompt engineer. "
                "Given a rough idea, write ONE detailed, creative prompt "
                "optimised for AI image or video generation. "
                "Include: subject, style, lighting, camera angle, mood, colour palette. "
                "Output only the prompt \u2014 no preamble, no explanation."
            )
            response = model.generate_content(
                [{"role": "user", "parts": [system + "\n\nIdea: " + self.idea]}]
            )
            result = response.text.strip() if response.text else ""
            if not result:
                raise Exception("Empty response from Gemini")
            with jobs_lock:
                jobs[self.job_id].update({"state": "done", "result": result})
        except Exception as e:
            with jobs_lock:
                jobs[self.job_id].update({"state": "error", "error": str(e)})


class ImageZAITask:
    def __init__(self, job_id, prompt):
        self.job_id = job_id
        self.prompt = prompt

    def _progress(self, msg):
        with jobs_lock:
            jobs[self.job_id].update({"progress": msg})

    def run(self):
        from playwright.sync_api import sync_playwright
        pw = sync_playwright().start()
        browser = None
        try:
            if not os.path.exists(ZAI_STORAGE):
                raise Exception(
                    "zai_auth.json not found. Run:\n"
                    "  playwright codegen --save-storage=zai_auth.json https://image.z.ai\n"
                    "Log in, close the browser, then try again."
                )
            browser = pw.chromium.launch(
                headless=False,
                args=["--disable-blink-features=AutomationControlled"]
            )
            context = browser.new_context(
                storage_state=ZAI_STORAGE,
                viewport={"width": 1280, "height": 800},
                user_agent=(
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
                ),
            )
            context.add_init_script(
                "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
            )
            page = context.new_page()
            self._gen(page)
            try:
                page.close()
                context.close()
                browser.close()
            except Exception:
                pass
        except Exception as e:
            with jobs_lock:
                current = jobs.get(self.job_id, {})
                if current.get("state") != "done":
                    jobs[self.job_id].update({"state": "error", "error": str(e)})
        finally:
            if browser:
                try:
                    browser.close()
                except Exception:
                    pass
            pw.stop()

    def _gen(self, page):
        self._progress("Opening image.z.ai\u2026")
        page.goto("https://image.z.ai/", wait_until="domcontentloaded", timeout=30_000)
        page.wait_for_timeout(4000)

        text = page.evaluate("() => document.body.innerText.substring(0,1000)").lower()
        if "log in" in text or "sign in" in text or "login" in text:
            raise Exception(
                "Session expired. Re-run:\n"
                "  playwright codegen --save-storage=zai_auth.json https://image.z.ai"
            )

        try:
            page.keyboard.press("Escape"); page.wait_for_timeout(300)
        except Exception:
            pass

        self._progress("Setting resolution to 2K\u2026")
        for attempt in range(2):
            try:
                page.get_by_role("combobox").filter(
                    has_text="1K" if attempt == 0 else "K"
                ).first.click(timeout=5000)
                page.wait_for_timeout(400)
                page.get_by_role("option", name="2K").click(timeout=3000)
                page.wait_for_timeout(600)
                break
            except Exception:
                pass
        else:
            self._progress("Couldn't set 2K, using default\u2026")

        self._progress("Entering prompt\u2026")
        textbox = page.get_by_role("textbox", name="Enter your creative")
        textbox.click(timeout=5000)
        page.wait_for_timeout(300)
        textbox.fill("")
        page.wait_for_timeout(100)
        textbox.fill(self.prompt)
        page.wait_for_timeout(300)

        old_src = page.evaluate("""() => {
            const img = document.querySelector('img[alt="Generated"]');
            return img ? (img.currentSrc || img.src || '') : '';
        }""")

        self._progress("Generating (30-120s)\u2026")
        page.get_by_role("button", name="generate Start Generation").click(timeout=5000)

        try:
            page.wait_for_function("""(oldSrc) => {
                const img = document.querySelector('img[alt="Generated"]');
                if (!img) return false;
                const newSrc = img.currentSrc || img.src || '';
                if (oldSrc && newSrc === oldSrc) return false;
                return (img.naturalWidth || 0) >= 512 && (img.naturalHeight || 0) >= 512 && newSrc.length > 20;
            }""", arg=old_src, timeout=180_000)
        except Exception:
            raise Exception("Image generation timed out")

        page.wait_for_timeout(3000)
        self._progress("Extracting image URL\u2026")
        img_url = self._extract_image_url(page)
        if not img_url:
            raise Exception("Image appeared but could not extract URL")

        self._progress("Downloading\u2026")
        filename = f"img_{self.job_id}.png"
        content = None
        try:
            resp = requests.get(img_url, timeout=120, stream=True)
            resp.raise_for_status()
            content = resp.content
        except Exception:
            pass

        if not content or len(content) < 5000:
            self._progress("Fetching through browser\u2026")
            content = self._download_via_browser(page, img_url)

        if not content or len(content) < 5000:
            raise Exception(f"Image too small ({len(content) if content else 0} bytes)")

        with open(os.path.join(IMAGE_DIR, filename), "wb") as f:
            f.write(content)

        with jobs_lock:
            jobs[self.job_id].update({
                "state": "done",
                "url": f"/static/images/{filename}",
                "type": "image",
                "size": len(content),
            })

    def _extract_image_url(self, page):
        img_data = page.evaluate("""() => {
            const img = document.querySelector('img[alt="Generated"]');
            if (!img) return null;
            return { src: img.currentSrc || img.src || '', srcset: img.srcset || '' };
        }""")
        if not img_data:
            return None

        def real(src):
            if not src or src.startswith("data:") or src.startswith("blob:"):
                return None
            if "/_next/image?" in src:
                try:
                    params = parse_qs(src.split("?", 1)[1])
                    if "url" in params:
                        return unquote(params["url"][0])
                except Exception:
                    pass
            if src.startswith("http"):
                return src
            return None

        url = real(img_data["src"])
        if not url and img_data.get("srcset"):
            for entry in img_data["srcset"].split(","):
                url = real(entry.strip().split(" ")[0].strip())
                if url:
                    break
        if not url:
            url = img_data["src"]
            if url.startswith("/"):
                url = "https://image.z.ai" + url
        return url

    def _download_via_browser(self, page, url):
        b64 = page.evaluate("""async (url) => {
            try {
                const resp = await fetch(url);
                if (!resp.ok) return null;
                const blob = await resp.blob();
                if (blob.size < 1000) return null;
                return new Promise(resolve => {
                    const reader = new FileReader();
                    reader.onloadend = () => resolve(reader.result);
                    reader.readAsDataURL(blob);
                });
            } catch { return null; }
        }""", url)
        if b64 and "," in b64:
            return base64.b64decode(b64.split(",", 1)[1])
        raise Exception("Browser fetch also failed")


# ─── ROUTES ────────────────────────────────────────────────────────────────────

@app.route("/")
@require_login
def index():
    return render_template("index.html")


# ── Chat ──────────────────────────────────────────────────────────────────────

@app.route("/chat-stream", methods=["POST"])
@require_login
def chat_stream():
    data    = request.json or {}
    message = data.get("message", "").strip()
    if not message:
        return Response(
            'data: ' + json.dumps({"error": "Empty message"}) + '\n\n',
            mimetype="text/event-stream"
        )

    def generate():
        try:
            model = genai.GenerativeModel("gemini-2.0-flash")
            with chat_lock:
                history_copy = list(chat_history)

            gemini_history = [
                genai.types.ContentDict(
                    role=entry["role"],
                    parts=[genai.types.PartDict(text=entry["text"])]
                )
                for entry in history_copy
            ]

            chat = model.start_chat(history=gemini_history)
            response = chat.send_message(message, stream=True)
            full_text = ""

            for chunk in response:
                try:
                    if not chunk.candidates:
                        continue
                    for part in chunk.candidates[0].content.parts:
                        if getattr(part, "thought", False):
                            continue
                        if getattr(part, "inline_data", None):
                            continue
                        if getattr(part, "text", None):
                            full_text += part.text
                            yield "data: " + json.dumps({"text": part.text}) + "\n\n"
                except Exception:
                    pass

            with chat_lock:
                chat_history.append({"role": "user",  "text": message})
                chat_history.append({"role": "model", "text": full_text})
                while len(chat_history) > 100:
                    chat_history.pop(0)

        except Exception as e:
            err = str(e)
            if "not found" in err.lower() or "does not exist" in err.lower():
                err = "Model not available. Check the model ID in Google AI Studio."
            yield "data: " + json.dumps({"error": err}) + "\n\n"

    return Response(
        generate(),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.route("/chat-clear", methods=["POST"])
@require_login
def chat_clear():
    with chat_lock:
        chat_history.clear()
    return jsonify({"status": "ok"})


# ── Generation ────────────────────────────────────────────────────────────────

@app.route("/generate", methods=["POST"])
@require_login
def generate_endpoint():
    data     = request.json or {}
    prompt   = data.get("prompt", "").strip()
    mode     = data.get("mode", "image")
    aspect   = data.get("aspect", "VIDEO_ASPECT_RATIO_LANDSCAPE")
    v_model  = data.get("video_model", "grok")

    if not prompt:
        return jsonify({"error": "Prompt is required"}), 400

    job_id = str(int(time.time() * 1000))
    with jobs_lock:
        jobs[job_id] = {"state": "processing", "type": mode, "progress": "Starting\u2026"}

    task = AutomationTask(job_id, prompt, mode, aspect, video_model=v_model)
    threading.Thread(target=task.run, daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/generate-img2vid", methods=["POST"])
@require_login
def generate_img2vid():
    if "image" not in request.files:
        return jsonify({"error": "No image file provided"}), 400

    image_file = request.files["image"]
    prompt     = request.form.get("prompt", "")
    aspect     = request.form.get("aspect", "VIDEO_ASPECT_RATIO_LANDSCAPE")
    ext        = os.path.splitext(image_file.filename)[1] or ".png"
    temp_path  = os.path.join(TEMP_DIR, f"upload_{uuid.uuid4().hex[:8]}{ext}")
    image_file.save(temp_path)

    job_id = str(int(time.time() * 1000))
    with jobs_lock:
        jobs[job_id] = {"state": "processing", "type": "image_to_video", "progress": "Starting\u2026"}

    task   = AutomationTask(job_id, prompt, "image_to_video", aspect, image_path=temp_path)
    thread = threading.Thread(target=task.run, daemon=True)
    thread.start()

    def _cleanup():
        thread.join()
        try:
            if os.path.exists(temp_path):
                os.remove(temp_path)
        except Exception:
            pass

    threading.Thread(target=_cleanup, daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/generate-prompt", methods=["POST"])
@require_login
def generate_prompt():
    data  = request.json or {}
    idea  = data.get("idea", "").strip()
    if not idea:
        return jsonify({"error": "Idea is required"}), 400

    job_id = str(int(time.time() * 1000))
    with jobs_lock:
        jobs[job_id] = {"state": "processing", "type": "prompt", "progress": "Starting\u2026"}

    task = PromptGeneratorTask(job_id, idea)
    threading.Thread(target=task.run, daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/generate-zai", methods=["POST"])
@require_login
def generate_zai():
    data   = request.json or {}
    prompt = data.get("prompt", "").strip()
    if not prompt:
        return jsonify({"error": "Prompt is required"}), 400

    job_id = str(int(time.time() * 1000))
    with jobs_lock:
        jobs[job_id] = {"state": "processing", "type": "image", "progress": "Starting\u2026"}

    task = ImageZAITask(job_id, prompt)
    threading.Thread(target=task.run, daemon=True).start()
    return jsonify({"job_id": job_id})


@app.route("/zai-session-status")
@require_login
def zai_session_status():
    return jsonify({"ready": os.path.exists(ZAI_STORAGE)})


# ── Status / File Management ──────────────────────────────────────────────────

@app.route("/status")
@require_login
def get_status():
    with jobs_lock:
        snapshot = dict(jobs)

    history = []
    for folder, t in [(IMAGE_DIR, "image"), (VIDEO_DIR, "video")]:
        if os.path.exists(folder):
            for f in os.listdir(folder):
                path = os.path.join(folder, f)
                if os.path.isfile(path):
                    history.append({
                        "url": f"/static/{t}s/{f}",
                        "filename": f,
                        "type": t,
                        "t": os.path.getctime(path),
                    })
    history.sort(key=lambda x: x["t"], reverse=True)
    return jsonify({"history": history, "active_jobs": snapshot})


@app.route("/delete", methods=["POST"])
@require_login
def delete_file():
    data   = request.json or {}
    folder = IMAGE_DIR if data.get("type") == "image" else VIDEO_DIR
    try:
        path = os.path.join(folder, data["filename"])
        if os.path.exists(path):
            os.remove(path)
            return jsonify({"status": "ok"})
        return jsonify({"status": "error", "message": "File not found"}), 404
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


# ── Debug ─────────────────────────────────────────────────────────────────────

@app.route("/debug-screenshot/<job_id>")
@require_login
def debug_screenshot(job_id):
    """View the screenshot taken when a video job failed."""
    path = os.path.join(TEMP_DIR, f"debug_{job_id}.png")
    if not os.path.exists(path):
        return jsonify({"error": "No screenshot available for this job"}), 404
    return Response(
        open(path, "rb").read(),
        mimetype="image/png",
        headers={"Cache-Control": "no-cache"},
    )


# ─── ENTRY POINT ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=True, port=5000, threaded=True)