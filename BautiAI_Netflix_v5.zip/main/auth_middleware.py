"""
auth_middleware.py  -  BautiAI complete auth system
"""
import os, json, uuid, secrets, requests
from datetime import datetime, timedelta
from functools import wraps
from flask import request, jsonify, session, redirect, render_template_string, make_response

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
USERS_FILE  = os.path.join(BASE_DIR, "..", "users.json")
AVATARS_DIR = os.path.join(BASE_DIR, "..", "avatars")
TOKENS_FILE = os.path.join(BASE_DIR, "..", "tokens.json")
os.makedirs(AVATARS_DIR, exist_ok=True)

COOKIE_NAME = "bautiai_token"
COOKIE_DAYS = 30
PAYPAL_CLIENT_ID = "AY2VrOog_bSOeHXIc6WClCucvYzxTZ1YPPhT74ZGXynz-x3eJ0x6hNihmO_Qm14Y4arpNmJ34cRcQvEe"
PAYPAL_SECRET    = os.environ.get("PAYPAL_SECRET", "")
PAYPAL_API_BASE  = "https://api-m.paypal.com"

# Tokens

def _load_tokens():
    if not os.path.exists(TOKENS_FILE): return {}
    try:
        with open(TOKENS_FILE) as f: return json.load(f)
    except: return {}

def _save_tokens(t):
    with open(TOKENS_FILE, "w") as f: json.dump(t, f, indent=2)

def _create_token(username):
    tok = secrets.token_hex(32)
    tokens = _load_tokens()
    now = datetime.utcnow().isoformat()
    tokens = {k: v for k, v in tokens.items() if v.get("expires","") > now}
    tokens[tok] = {"username": username, "expires": (datetime.utcnow() + timedelta(days=COOKIE_DAYS)).isoformat()}
    _save_tokens(tokens)
    return tok

def _validate_token(tok):
    if not tok: return None
    tokens = _load_tokens()
    e = tokens.get(tok)
    if not e or e.get("expires","") < datetime.utcnow().isoformat(): return None
    return e["username"]

def _revoke_token(tok):
    tokens = _load_tokens()
    tokens.pop(tok, None)
    _save_tokens(tokens)

# Users

def _load_users():
    if not os.path.exists(USERS_FILE): return {}
    try:
        with open(USERS_FILE) as f: return json.load(f)
    except: return {}

def _save_users(u):
    with open(USERS_FILE, "w") as f: json.dump(u, f, indent=2)

def _ensure_profiles(user):
    if not user.get("profiles"):
        user["profiles"] = [{"id": str(uuid.uuid4())[:8], "name": "Principal",
            "avatar": None, "favorites": [], "watch_progress": {}, "history": []}]
    return user

def _find_profile(user, pid):
    for p in user.get("profiles", []):
        if p["id"] == pid: return p
    return None

# PayPal

def check_subscription_active(sub_id):
    if sub_id in ("MANUAL_ADMIN", ""): return True
    if not PAYPAL_SECRET: return True
    try:
        r = requests.post(f"{PAYPAL_API_BASE}/v1/oauth2/token",
            auth=(PAYPAL_CLIENT_ID, PAYPAL_SECRET),
            data={"grant_type": "client_credentials"}, timeout=10)
        tok = r.json()["access_token"]
        r2 = requests.get(f"{PAYPAL_API_BASE}/v1/billing/subscriptions/{sub_id}",
            headers={"Authorization": f"Bearer {tok}"}, timeout=10)
        return r2.status_code == 200 and r2.json().get("status") == "ACTIVE"
    except: return True

# Auth helpers

def _current_user():
    if session.get("logged_in"): return session.get("username")
    tok = request.cookies.get(COOKIE_NAME)
    username = _validate_token(tok)
    if username:
        session["logged_in"] = True
        session["username"] = username
    return username

def is_logged_in():
    return _current_user() is not None

def require_login(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not _current_user():
            if request.is_json or request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return jsonify({"error": "not_authenticated"}), 401
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated


LOGIN_HTML = '<!DOCTYPE html>\n<html lang="es">\n<head>\n<meta charset="UTF-8"/>\n<meta name="viewport" content="width=device-width,initial-scale=1"/>\n<title>BautiAI</title>\n<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">\n<style>\n*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}\nbody{min-height:100vh;background:#0a0a0f;display:flex;align-items:center;justify-content:center;font-family:\'DM Sans\',sans-serif;color:#e8e8f0;overflow:hidden}\n.bg{position:fixed;inset:0;z-index:0;background:radial-gradient(ellipse 80% 60% at 20% 10%,rgba(229,9,20,.12),transparent),radial-gradient(ellipse 60% 80% at 80% 90%,rgba(229,9,20,.08),transparent),#0a0a0f}\n.wrap{position:relative;z-index:1;width:100%;max-width:420px;padding:1rem}\n.logo-text{font-family:\'Bebas Neue\',sans-serif;font-size:3rem;letter-spacing:.15em;color:#e50914;text-align:center;margin-bottom:.2rem}\n.logo-sub{text-align:center;font-size:.7rem;letter-spacing:.3em;text-transform:uppercase;color:rgba(255,255,255,.3);margin-bottom:2rem}\n.card{background:rgba(15,15,25,.9);border:1px solid rgba(255,255,255,.08);border-radius:20px;padding:2.2rem 2.4rem;backdrop-filter:blur(24px)}\n.tabs{display:flex;gap:.3rem;background:rgba(255,255,255,.04);border-radius:10px;padding:.25rem;margin-bottom:1.8rem}\n.tab{flex:1;padding:.55rem;border:none;border-radius:8px;background:transparent;color:rgba(255,255,255,.4);cursor:pointer;font-family:\'DM Sans\',sans-serif;font-size:.82rem;font-weight:600;transition:all .2s}\n.tab.active{background:#e50914;color:#fff}\n.form-section{display:none}.form-section.active{display:block}\n.field{margin-top:1rem}\nlabel{display:block;font-size:.72rem;font-weight:600;color:rgba(255,255,255,.4);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.4rem}\ninput[type=text],input[type=password]{width:100%;padding:.75rem 1rem;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:10px;color:#f0f0f8;font-family:\'DM Sans\',sans-serif;font-size:.95rem;outline:none;transition:border-color .2s,box-shadow .2s}\ninput::placeholder{color:rgba(255,255,255,.18)}\ninput:focus{border-color:rgba(229,9,20,.5);box-shadow:0 0 0 3px rgba(229,9,20,.12)}\n.btn{margin-top:1.5rem;width:100%;padding:.85rem;background:#e50914;border:none;border-radius:10px;color:#fff;font-family:\'DM Sans\',sans-serif;font-size:.95rem;font-weight:700;cursor:pointer;transition:all .2s}\n.btn:hover{background:#f40612;transform:translateY(-1px)}\n.msg{margin-top:.8rem;text-align:center;font-size:.82rem;min-height:1.1em;color:#f87171}\n.msg.ok{color:#4ade80}\n.divider{display:flex;align-items:center;gap:.6rem;margin:1.4rem 0 1rem;color:rgba(255,255,255,.2);font-size:.72rem;letter-spacing:.1em;text-transform:uppercase}\n.divider::before,.divider::after{content:\'\';flex:1;height:1px;background:rgba(255,255,255,.08)}\n.hint{font-size:.78rem;color:rgba(255,255,255,.35);text-align:center;line-height:1.6;margin-bottom:.5rem}\n</style>\n</head>\n<body>\n<div class="bg"></div>\n<div class="wrap">\n  <div class="logo-text">BAUTIAI</div>\n  <div class="logo-sub">Streaming Premium</div>\n  <div class="card">\n    <div class="tabs">\n      <button class="tab active" onclick="showTab(\'login\')">Iniciar sesion</button>\n      <button class="tab" onclick="showTab(\'register\')">Crear cuenta</button>\n    </div>\n    <div id="tab-login" class="form-section active">\n      <div class="field"><label>Usuario</label><input type="text" id="login-user" placeholder="Tu usuario" autocomplete="username"/></div>\n      <div class="field"><label>Contrasena</label><input type="password" id="login-pass" placeholder="Tu contrasena" autocomplete="current-password" onkeydown="if(event.key===\'Enter\')doLogin()"/></div>\n      <button class="btn" onclick="doLogin()">Entrar</button>\n      <div id="login-msg" class="msg"></div>\n    </div>\n    <div id="tab-register" class="form-section">\n      <p class="hint">Elegi tu usuario y contrasena, luego suscribite con PayPal.</p>\n      <div class="field"><label>Usuario</label><input type="text" id="reg-user" placeholder="Min. 3 caracteres"/></div>\n      <div class="field"><label>Contrasena</label><input type="password" id="reg-pass" placeholder="Min. 6 caracteres"/></div>\n      <div class="divider">Pagar con PayPal</div>\n      <div id="paypal-button-container-P-6CD533193L567335FNHKEEQA"></div>\n      <div id="reg-msg" class="msg"></div>\n    </div>\n  </div>\n</div>\n<script src="https://www.paypal.com/sdk/js?client-id=AY2VrOog_bSOeHXIc6WClCucvYzxTZ1YPPhT74ZGXynz-x3eJ0x6hNihmO_Qm14Y4arpNmJ34cRcQvEe&vault=true&intent=subscription" data-sdk-integration-source="button-factory"></script>\n<script>\nfunction showTab(t){\n  document.querySelectorAll(\'.tab\').forEach((b,i)=>b.classList.toggle(\'active\',(i===0&&t===\'login\')||(i===1&&t===\'register\')));\n  document.getElementById(\'tab-login\').classList.toggle(\'active\',t===\'login\');\n  document.getElementById(\'tab-register\').classList.toggle(\'active\',t===\'register\');\n}\nasync function doLogin(){\n  const u=document.getElementById(\'login-user\').value.trim();\n  const p=document.getElementById(\'login-pass\').value;\n  const msg=document.getElementById(\'login-msg\');\n  if(!u||!p){msg.textContent=\'Completa usuario y contrasena.\';return;}\n  msg.className=\'msg\';msg.textContent=\'Verificando...\';\n  try{\n    const r=await fetch(\'/auth/login\',{method:\'POST\',headers:{\'Content-Type\':\'application/json\'},body:JSON.stringify({username:u,password:p})});\n    const d=await r.json();\n    if(d.ok){msg.className=\'msg ok\';msg.textContent=\'Bienvenido!\';setTimeout(()=>location.href=\'/\',800);}\n    else msg.textContent=d.error;\n  }catch(e){msg.textContent=\'Error de conexion.\';}\n}\npaypal.Buttons({\n  style:{shape:\'rect\',color:\'black\',layout:\'vertical\',label:\'subscribe\'},\n  createSubscription:function(data,actions){\n    const u=document.getElementById(\'reg-user\').value.trim();\n    const p=document.getElementById(\'reg-pass\').value;\n    const msg=document.getElementById(\'reg-msg\');\n    if(!u||u.length<3){msg.textContent=\'Usuario muy corto\';return Promise.reject();}\n    if(!p||p.length<6){msg.textContent=\'Contrasena muy corta\';return Promise.reject();}\n    msg.textContent=\'\';\n    return actions.subscription.create({plan_id:\'P-6CD533193L567335FNHKEEQA\'});\n  },\n  onApprove:async function(data){\n    const msg=document.getElementById(\'reg-msg\');\n    msg.className=\'msg ok\';msg.textContent=\'Pago aprobado. Creando cuenta...\';\n    const r=await fetch(\'/auth/register\',{method:\'POST\',headers:{\'Content-Type\':\'application/json\'},body:JSON.stringify({username:document.getElementById(\'reg-user\').value.trim(),password:document.getElementById(\'reg-pass\').value,subscription_id:data.subscriptionID})});\n    const res=await r.json();\n    if(res.ok){msg.textContent=\'Cuenta creada!\';setTimeout(()=>location.href=\'/\',1000);}\n    else{msg.textContent=res.error;msg.className=\'msg\';}\n  },\n  onError:function(){document.getElementById(\'reg-msg\').textContent=\'Pago cancelado o fallo.\';}\n}).render(\'#paypal-button-container-P-6CD533193L567335FNHKEEQA\');\n</script>\n</body></html>'

def register_auth_routes(app):
    app.secret_key = os.environ.get("FLASK_SECRET", secrets.token_hex(32))

    @app.route("/avatars/<filename>")
    def serve_avatar(filename):
        from flask import send_from_directory
        return send_from_directory(AVATARS_DIR, filename)

    @app.route("/login")
    def login_page():
        if is_logged_in(): return redirect("/")
        return render_template_string(LOGIN_HTML)

    @app.route("/auth/login", methods=["POST"])
    def auth_login():
        data = request.get_json(force=True)
        username = data.get("username","").strip()
        password = data.get("password","")
        users = _load_users()
        if username not in users:
            return jsonify({"ok":False,"error":"Usuario no encontrado."})
        user = _ensure_profiles(users[username])
        if user["password"] != password:
            return jsonify({"ok":False,"error":"Contrasena incorrecta."})
        if not check_subscription_active(user.get("subscription_id","")):
            return jsonify({"ok":False,"error":"Suscripcion inactiva."})
        users[username] = user
        _save_users(users)
        session["logged_in"] = True
        session["username"] = username
        tok = _create_token(username)
        resp = jsonify({"ok":True,"profiles":user["profiles"]})
        resp.set_cookie(COOKIE_NAME, tok, max_age=COOKIE_DAYS*86400, httponly=True, samesite="Lax", secure=False)
        return resp

    @app.route("/auth/register", methods=["POST"])
    def auth_register():
        data = request.get_json(force=True)
        username = data.get("username","").strip()
        password = data.get("password","")
        sub_id   = data.get("subscription_id","")
        if not username or len(username)<3: return jsonify({"ok":False,"error":"Usuario invalido."})
        if not password or len(password)<6: return jsonify({"ok":False,"error":"Contrasena muy corta."})
        if not sub_id: return jsonify({"ok":False,"error":"Sin ID PayPal."})
        users = _load_users()
        if username in users: return jsonify({"ok":False,"error":"Usuario ya existe."})
        if not check_subscription_active(sub_id): return jsonify({"ok":False,"error":"Suscripcion no activa."})
        new_user = {"password":password,"subscription_id":sub_id,"subscription_status":"active",
            "created_at":datetime.utcnow().isoformat(),
            "profiles":[{"id":str(uuid.uuid4())[:8],"name":username,"avatar":None,
                "favorites":[],"watch_progress":{},"history":[]}]}
        users[username] = new_user
        _save_users(users)
        session["logged_in"] = True
        session["username"] = username
        tok = _create_token(username)
        resp = jsonify({"ok":True})
        resp.set_cookie(COOKIE_NAME, tok, max_age=COOKIE_DAYS*86400, httponly=True, samesite="Lax", secure=False)
        return resp

    @app.route("/auth/logout")
    def auth_logout():
        tok = request.cookies.get(COOKIE_NAME)
        if tok: _revoke_token(tok)
        session.clear()
        resp = make_response(redirect("/login"))
        resp.delete_cookie(COOKIE_NAME)
        return resp

    @app.route("/auth/me")
    def auth_me():
        username = _current_user()
        if not username: return jsonify({"ok":False,"error":"not_authenticated"}),401
        users = _load_users()
        user = _ensure_profiles(users.get(username,{}))
        return jsonify({"ok":True,"username":username,"profiles":user.get("profiles",[])})

    @app.route("/auth/change-password", methods=["POST"])
    def auth_change_password():
        username = _current_user()
        if not username: return jsonify({"ok":False,"error":"No autenticado."}),401
        data = request.get_json(force=True)
        old_pw = data.get("old_password","")
        new_pw = data.get("new_password","")
        if not old_pw or not new_pw: return jsonify({"ok":False,"error":"Faltan campos."})
        if len(new_pw)<6: return jsonify({"ok":False,"error":"Nueva contrasena muy corta."})
        users = _load_users()
        user = users.get(username,{})
        if user.get("password") != old_pw: return jsonify({"ok":False,"error":"Contrasena actual incorrecta."})
        users[username]["password"] = new_pw
        _save_users(users)
        return jsonify({"ok":True})

    # -- Profiles --

    @app.route("/api/profiles")
    @require_login
    def api_profiles():
        username = _current_user()
        users = _load_users()
        user = _ensure_profiles(users[username])
        return jsonify({"ok":True,"profiles":user["profiles"]})

    @app.route("/api/profiles/create", methods=["POST"])
    @require_login
    def api_profile_create():
        username = _current_user()
        data = request.get_json(force=True)
        name = data.get("name","").strip()
        if not name: return jsonify({"ok":False,"error":"Nombre requerido."})
        users = _load_users()
        user = _ensure_profiles(users[username])
        if len(user["profiles"]) >= 5: return jsonify({"ok":False,"error":"Maximo 5 perfiles."})
        p = {"id":str(uuid.uuid4())[:8],"name":name,"avatar":None,"favorites":[],"watch_progress":{},"history":[]}
        user["profiles"].append(p)
        users[username] = user
        _save_users(users)
        return jsonify({"ok":True,"profile":p})

    @app.route("/api/profiles/delete", methods=["POST"])
    @require_login
    def api_profile_delete():
        username = _current_user()
        data = request.get_json(force=True)
        pid = data.get("profile_id","")
        users = _load_users()
        user = _ensure_profiles(users[username])
        if len(user["profiles"]) <= 1: return jsonify({"ok":False,"error":"No puedes eliminar el unico perfil."})
        user["profiles"] = [p for p in user["profiles"] if p["id"] != pid]
        users[username] = user; _save_users(users)
        return jsonify({"ok":True})

    @app.route("/api/profiles/rename", methods=["POST"])
    @require_login
    def api_profile_rename():
        username = _current_user()
        data = request.get_json(force=True)
        pid = data.get("profile_id",""); name = data.get("name","").strip()
        if not name: return jsonify({"ok":False,"error":"Nombre requerido."})
        users = _load_users()
        user = _ensure_profiles(users[username])
        for p in user["profiles"]:
            if p["id"] == pid: p["name"] = name; break
        users[username] = user; _save_users(users)
        return jsonify({"ok":True})

    @app.route("/api/profiles/avatar", methods=["POST"])
    @require_login
    def api_profile_avatar():
        username = _current_user()
        pid  = request.form.get("profile_id","")
        file = request.files.get("avatar")
        if not file or not pid: return jsonify({"ok":False,"error":"Faltan datos."})
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in (".jpg",".jpeg",".png",".gif",".webp"): return jsonify({"ok":False,"error":"Formato no soportado."})
        fname = f"{username}_{pid}{ext}"
        file.save(os.path.join(AVATARS_DIR, fname))
        url = f"/avatars/{fname}"
        users = _load_users()
        user = _ensure_profiles(users[username])
        for p in user["profiles"]:
            if p["id"] == pid: p["avatar"] = url; break
        users[username] = user; _save_users(users)
        return jsonify({"ok":True,"avatar":url})

    # -- Favorites --

    @app.route("/api/favorites")
    @require_login
    def api_favorites():
        username = _current_user()
        pid = request.args.get("profile_id","")
        users = _load_users()
        user = _ensure_profiles(users[username])
        prof = _find_profile(user, pid)
        if not prof: return jsonify({"ok":False,"error":"Perfil no encontrado."})
        return jsonify({"ok":True,"favorites":prof.get("favorites",[])})

    @app.route("/api/favorites/toggle", methods=["POST"])
    @require_login
    def api_favorites_toggle():
        username = _current_user()
        data = request.get_json(force=True)
        pid  = data.get("profile_id","")
        item = data.get("item")
        if not pid or not item: return jsonify({"ok":False,"error":"Faltan datos."})
        tmdb_id = str(item.get("tmdb_id",""))
        users = _load_users()
        user = _ensure_profiles(users[username])
        prof = _find_profile(user, pid)
        if not prof: return jsonify({"ok":False,"error":"Perfil no encontrado."})
        favs = prof.get("favorites",[])
        idx = next((i for i,f in enumerate(favs) if str(f.get("tmdb_id"))==tmdb_id), None)
        if idx is not None:
            favs.pop(idx); action="removed"
        else:
            item["tmdb_id"] = tmdb_id
            item["added_at"] = datetime.utcnow().isoformat()
            favs.insert(0, item); action="added"
        prof["favorites"] = favs
        users[username] = user; _save_users(users)
        return jsonify({"ok":True,"action":action})

    # -- Watch progress --

    @app.route("/api/progress/save", methods=["POST"])
    @require_login
    def api_progress_save():
        username = _current_user()
        data = request.get_json(force=True)
        pid     = data.get("profile_id","")
        tmdb_id = str(data.get("tmdb_id",""))
        prog    = data.get("progress")
        if not pid or not tmdb_id or not prog: return jsonify({"ok":False})
        users = _load_users()
        user = _ensure_profiles(users[username])
        prof = _find_profile(user, pid)
        if not prof: return jsonify({"ok":False})
        prog["updated_at"] = datetime.utcnow().isoformat()
        prof.setdefault("watch_progress",{})[tmdb_id] = prog
        users[username] = user; _save_users(users)
        return jsonify({"ok":True})

    @app.route("/api/progress")
    @require_login
    def api_progress():
        username = _current_user()
        pid     = request.args.get("profile_id","")
        tmdb_id = request.args.get("tmdb_id","")
        users = _load_users()
        user = _ensure_profiles(users[username])
        prof = _find_profile(user, pid)
        if not prof: return jsonify({"ok":False})
        wp = prof.get("watch_progress",{})
        if tmdb_id: return jsonify({"ok":True,"progress":wp.get(str(tmdb_id))})
        return jsonify({"ok":True,"all":wp})

    # -- History --

    @app.route("/api/history/add", methods=["POST"])
    @require_login
    def api_history_add():
        username = _current_user()
        data = request.get_json(force=True)
        pid  = data.get("profile_id","")
        item = data.get("item")
        if not pid or not item: return jsonify({"ok":False})
        users = _load_users()
        user = _ensure_profiles(users[username])
        prof = _find_profile(user, pid)
        if not prof: return jsonify({"ok":False})
        hist = prof.get("history",[])
        tmdb_id = str(item.get("tmdb_id",""))
        hist = [h for h in hist if str(h.get("tmdb_id","")) != tmdb_id]
        item["watched_at"] = datetime.utcnow().isoformat()
        hist.insert(0, item)
        prof["history"] = hist[:100]
        users[username] = user; _save_users(users)
        return jsonify({"ok":True})

    @app.route("/api/history")
    @require_login
    def api_history():
        username = _current_user()
        pid = request.args.get("profile_id","")
        users = _load_users()
        user = _ensure_profiles(users[username])
        prof = _find_profile(user, pid)
        if not prof: return jsonify({"ok":True,"history":[]})
        return jsonify({"ok":True,"history":prof.get("history",[])})

    @app.route("/auth/check-subscription")
    def auth_check_subscription():
        username = _current_user()
        if not username: return jsonify({"active":False}),401
        users = _load_users()
        user = users.get(username,{})
        active = check_subscription_active(user.get("subscription_id",""))
        if not active: session.clear()
        return jsonify({"active":active,"username":username})
